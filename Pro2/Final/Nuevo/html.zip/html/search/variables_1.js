var searchData=
[
  ['especial_99',['especial',['../class_alfabeto.html#a38f6ec3b0894e97eac15f7c6fe3a8205',1,'Alfabeto']]]
];
