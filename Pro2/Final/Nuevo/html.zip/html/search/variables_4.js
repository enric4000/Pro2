var searchData=
[
  ['nummensa_105',['Nummensa',['../class_alfabeto.html#ac39ef553d90ea7ae86086aeec17a81aa',1,'Alfabeto']]]
];
