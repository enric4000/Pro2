var searchData=
[
  ['codificación_20de_20mensajes_2e_107',['Codificación de mensajes.',['../index.html',1,'']]]
];
