var searchData=
[
  ['listar_5falfabetos_91',['listar_alfabetos',['../class_c_alfabetos.html#a5df5be207aa1b6841c0ba860f076bd83',1,'CAlfabetos']]],
  ['listar_5fmensajes_92',['listar_mensajes',['../class_c_mensajes.html#a0f9dcfbd3ef87a164735d4888220afee',1,'CMensajes']]]
];
