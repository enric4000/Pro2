var searchData=
[
  ['ida_100',['ida',['../class_mensaje.html#a48e0fe3ebc3c180467fcacd9f56fed86',1,'Mensaje']]],
  ['it_101',['it',['../class_c_alfabetos.html#ad82d8260fee08c059638517943847d01',1,'CAlfabetos']]]
];
