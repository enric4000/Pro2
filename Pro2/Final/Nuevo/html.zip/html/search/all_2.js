var searchData=
[
  ['borrar_5falfabeto_5',['borrar_alfabeto',['../class_c_alfabetos.html#ad834e95753ee035c7ad5a8c30404c17b',1,'CAlfabetos']]],
  ['borrar_5fmensaje_6',['borrar_mensaje',['../class_c_mensajes.html#ac6520b6a80ab6f014a26c04dfed3c9e5',1,'CMensajes']]],
  ['buscaida_7',['buscaida',['../class_c_alfabetos.html#aa70b0535254cb7134813e70c1ae3ecec',1,'CAlfabetos']]]
];
