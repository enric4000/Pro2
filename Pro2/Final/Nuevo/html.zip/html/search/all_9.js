var searchData=
[
  ['nuevo_5falfabeto_47',['nuevo_alfabeto',['../class_c_alfabetos.html#a0197d6f46a72d59c1ebc938232d21476',1,'CAlfabetos']]],
  ['nuevo_5fmensaje_48',['nuevo_mensaje',['../class_c_mensajes.html#ae2cb7d14ac1bfcb102b84d1b072c1ab7',1,'CMensajes']]],
  ['nummensa_49',['Nummensa',['../class_alfabeto.html#ac39ef553d90ea7ae86086aeec17a81aa',1,'Alfabeto']]]
];
