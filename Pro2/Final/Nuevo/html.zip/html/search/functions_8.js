var searchData=
[
  ['nuevo_5falfabeto_95',['nuevo_alfabeto',['../class_c_alfabetos.html#a0197d6f46a72d59c1ebc938232d21476',1,'CAlfabetos']]],
  ['nuevo_5fmensaje_96',['nuevo_mensaje',['../class_c_mensajes.html#ae2cb7d14ac1bfcb102b84d1b072c1ab7',1,'CMensajes']]]
];
