var searchData=
[
  ['alfabeto_65',['Alfabeto',['../class_alfabeto.html#a218c7371b04d202f3c7bfbc2640f091a',1,'Alfabeto']]]
];
