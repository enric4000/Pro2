var indexSectionsWithContent =
{
  0: "_abcdeilmnprv",
  1: "abcm",
  2: "abcmp",
  3: "abcdeilmnrv",
  4: "_",
  5: "c"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "defines",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Tot",
  1: "Classes",
  2: "Fitxers",
  3: "Funcions",
  4: "Definicions",
  5: "Pàgines"
};

