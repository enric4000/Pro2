var searchData=
[
  ['empty_58',['empty',['../class_bin_tree.html#a74cda259ba5c25b8ee38ed4dc33e4fad',1,'BinTree']]]
];
