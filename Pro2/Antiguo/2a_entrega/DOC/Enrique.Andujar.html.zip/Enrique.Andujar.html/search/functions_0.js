var searchData=
[
  ['alfabeto_44',['Alfabeto',['../class_alfabeto.html#afaafcf71256a922e0ea672f3f6b6e3c2',1,'Alfabeto']]]
];
