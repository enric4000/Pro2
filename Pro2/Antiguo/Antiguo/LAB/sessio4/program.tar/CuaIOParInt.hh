#include "ParInt.hh"
#include <queue>
#include <iostream>

using namespace std;

void llegirCuaParInt(queue<ParInt>& c);

void escriureCuaParInt(queue<ParInt> c);
