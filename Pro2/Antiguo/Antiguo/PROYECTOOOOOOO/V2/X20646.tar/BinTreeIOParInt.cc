#include "BinTreeIOParInt.hh"

void read_bintree_parint(BinTree<ParInt>& a)
{
	ParInt par;
	par.llegir();
	BinTree<ParInt> bl,br;	
	if (par.primer()!= 0 and par.segon()!=0){
		//cout<<par.primer()<<' '<<par.segon()<<endl;
		read_bintree_parint(bl);
		read_bintree_parint(br);
	}
	BinTree<ParInt> b(par,bl,br);
	a=b;
}
