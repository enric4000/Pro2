var searchData=
[
  ['torneo_30',['torneo',['../classtorneo.html',1,'torneo'],['../classtorneo.html#a8922a3a39e14222f2ffb9faf2723550a',1,'torneo::torneo()']]],
  ['torneo_2ehh_31',['torneo.hh',['../torneo_8hh.html',1,'']]]
];
