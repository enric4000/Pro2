var searchData=
[
  ['torneo_37',['torneo',['../classtorneo.html',1,'']]]
];
