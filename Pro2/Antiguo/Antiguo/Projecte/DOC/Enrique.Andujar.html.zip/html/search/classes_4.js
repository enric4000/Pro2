var searchData=
[
  ['torneo_46',['torneo',['../classtorneo.html',1,'']]]
];
