var searchData=
[
  ['jugador_59',['jugador',['../classjugador.html#adb67bd8d7d8e75edc506e1eac6fdc8ca',1,'jugador']]]
];
