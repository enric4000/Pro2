var searchData=
[
  ['finalizatorneo_14',['finalizatorneo',['../classtorneo.html#a801b57cde7347a89e1aea6d5c491a8e1',1,'torneo']]],
  ['ft_15',['ft',['../classcircuito.html#a89f736bc31aca7c0ce128caf39de9d35',1,'circuito']]]
];
