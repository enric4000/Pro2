var searchData=
[
  ['aj_45',['aj',['../classranking.html#a0edfe8a40337b53808221690bade7e8f',1,'ranking']]],
  ['at_46',['at',['../classcircuito.html#a048cab627220bf14655f1d7cac5c7495',1,'circuito']]],
  ['añadirpuntosnivel_47',['añadirpuntosnivel',['../classcategoria.html#a0d22bea62bd4ccabbdc1c79e5c7741c1',1,'categoria::añadirpuntosnivel()'],['../class_ccategorias.html#a16a5ab435721c969d76ecc044d1b0ddf',1,'Ccategorias::añadirpuntosnivel()']]]
];
