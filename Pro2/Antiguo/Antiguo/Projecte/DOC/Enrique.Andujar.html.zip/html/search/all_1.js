var searchData=
[
  ['bj_3',['bj',['../classranking.html#a7c24e5d21c96d15118cbdad7d8ec40e9',1,'ranking']]],
  ['bt_4',['bt',['../classcircuito.html#a88bbecc3713c27a6b86b06c04133320c',1,'circuito']]]
];
