var searchData=
[
  ['jugador_35',['jugador',['../classjugador.html',1,'']]]
];
