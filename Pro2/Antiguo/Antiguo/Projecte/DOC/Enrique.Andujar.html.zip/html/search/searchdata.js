var indexSectionsWithContent =
{
  0: "abcfijlmrst",
  1: "cjrt",
  2: "cjmrt",
  3: "abcfijlmrst",
  4: "c"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "Tot",
  1: "Classes",
  2: "Fitxers",
  3: "Funcions",
  4: "Pàgines"
};

