var searchData=
[
  ['torneo_68',['torneo',['../classtorneo.html#a8922a3a39e14222f2ffb9faf2723550a',1,'torneo']]]
];
