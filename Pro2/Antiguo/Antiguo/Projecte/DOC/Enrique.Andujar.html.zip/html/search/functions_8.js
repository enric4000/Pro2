var searchData=
[
  ['ranking_65',['ranking',['../classranking.html#a70de401c3bcb97d8b781c6fb53931ee0',1,'ranking']]],
  ['restatorneo_66',['restatorneo',['../classjugador.html#ae15b52b6591817e2e4524db100b4cd7d',1,'jugador']]]
];
