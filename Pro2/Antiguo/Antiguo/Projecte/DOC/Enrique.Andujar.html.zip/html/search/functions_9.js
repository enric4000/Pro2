var searchData=
[
  ['sumatorneo_67',['sumatorneo',['../classjugador.html#aaf84889f507bed648fbca51b28472f48',1,'jugador']]]
];
