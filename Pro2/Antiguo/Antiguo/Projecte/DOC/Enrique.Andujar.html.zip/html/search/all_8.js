var searchData=
[
  ['ranking_26',['ranking',['../classranking.html',1,'ranking'],['../classranking.html#a70de401c3bcb97d8b781c6fb53931ee0',1,'ranking::ranking()']]],
  ['ranking_2ehh_27',['ranking.hh',['../ranking_8hh.html',1,'']]],
  ['restatorneo_28',['restatorneo',['../classjugador.html#ae15b52b6591817e2e4524db100b4cd7d',1,'jugador']]]
];
