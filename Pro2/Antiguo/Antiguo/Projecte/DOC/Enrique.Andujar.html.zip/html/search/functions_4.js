var searchData=
[
  ['iniciatorneo_57',['iniciatorneo',['../classtorneo.html#adc7dfd865d9a81fbca1b2749ff9f2300',1,'torneo']]],
  ['it_58',['it',['../classcircuito.html#a2e4273621382f6bca146af0f62eaa10b',1,'circuito']]]
];
