var searchData=
[
  ['categoria_32',['categoria',['../classcategoria.html',1,'']]],
  ['ccategorias_33',['Ccategorias',['../class_ccategorias.html',1,'']]],
  ['circuito_34',['circuito',['../classcircuito.html',1,'']]]
];
