#include <iostream>
#include <vector>
#include <algorithm>
#include "ranking.hh"
using namespace std;

	ranking::ranking(){}
	
	void ranking::aj(const string &p){

		map<string, jugador>::const_iterator it = mj.find(p);
		if(it != mj.end()) cout << "error: ya existe un jugador con ese nombre" << endl;
		else {
			jugador jug (p);
			mj.insert(make_pair(p, jug));
			mp.insert(make_pair(p, 0));

		}
	}
	void ranking::cj(const string &p){

		map<string, jugador>::const_iterator it = mj.find(p);
		if(it == mj.end()) cout << "error: el jugador no existe" << endl;
		else {
			jugador jo = it->second;
			cout << p << " Rk:";
			map<string, jugador>::const_iterator it1 = mj.begin();
			int x = 1;
			while(it1 != it) {
				++it1;
				++x;
			}
			cout << x;
			jo.consulta();
		}

	}
	bool ordena(pair<int, string> o1, pair<int, string> o2){ return o1.first < o2.first;}

	void ranking::bj(const string &p){

		if(mj.erase(p) == 0) cout << "error: el jugador no existe" << endl;
		else {
			map<string, int>::const_iterator it1 = mp.find(p);

			mp.erase(it1);
		}

	}
	void ranking::lr(){

		map<string, int>::const_iterator it = mp.begin();

		vector<pair<int, string>> orden(mp.size());
		for(int i = 0; i < mp.size(); ++i){

			orden[i] = make_pair(it->second, it->first);
			++it;
		}
		sort(orden.begin(), orden.end(), ordena);
		if(orden[0].first == 0) {
			it = mp.begin();
			for(int l = 0; l < mp.size(); ++l){

				cout << l + 1 << " " << it->second << " " << it->first << endl;
			}

		}
		else{


			for(int j = 0; j < orden.size(); ++j){

				cout << j + 1 << " " << orden[j].second << " " << orden[j].first << endl;

			}
		}


	}

	void ranking::lj(){

		map<string, jugador>::const_iterator it = mj.begin();
		for(int i = 0; i < mj.size(); ++i){

			jugador jo = it->second;
			cout << it->first << " ";
			jo.consulta();
			++it;
		}

	}