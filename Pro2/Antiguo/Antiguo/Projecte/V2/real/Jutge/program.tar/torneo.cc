#include <iostream>
#include <vector>
#include "torneo.hh"
using namespace std;

    torneo::torneo(const pair<string, string> &par1){
            
        nombre = par1.first;
        categoria = par1.second;
            
    }
    
    void torneo::iniciatorneo(ranking &rank){
        map<string, int>::const_iterator it = rank.mp.begin();
        map<int, string> orden;
        for(int i = 0; i < rank.mp.size(); ++i){

            orden.insert(make_pair(i, it->first));
            ++it;
        }

        int x, z;
        cin >> x;
        int y = 4;
        for(int j = 8; j < x; j *= 2){
            ++y;
        }
        vector<int> parti(x);
        for(int k = 0; k < x; ++k){
            
            cin >> z;
            parti[k] = z;
        }

        int numnivel = 1;

        vector<int> sumniv(y);

        sumniv[0] = 1;
        sumniv[1] = 2;

        for(int j = 2; j < y; ++j){

            sumniv[j] = numnivel;
            numnivel = numnivel*2 - 1;

        }
        BinTree<int> a;
        int i = 0, anterior = 1;
        read_bintree_int(a, anterior, i, sumniv, x);
        i = 0;
        hojas_bintree_int(a, orden, parti, i);
        cout << endl;
    }

    void torneo::hojas_bintree_int(const BinTree<int>& a, map<int, string> orden, vector<int> parti, int &i){

        cout << "(";
        if(not(a.left().empty())){

            hojas_bintree_int(a.left(), orden, parti, i);
            hojas_bintree_int(a.right(), orden, parti, i);
            cout << ")";
        }
        else{
            int x = parti[a.value() - 1];
            cout << a.value() << "." << orden[x] << " ";
            ++i;
        }

    }

    void torneo::read_bintree_int(BinTree<int>& a, int anterior, int &i, const vector<int> &sumniv, const int maxplay){

            ++i;
            int n = sumniv[i] - anterior;

            if( n < maxplay){

                BinTree<int> l;
                read_bintree_int(l, anterior, i, sumniv, maxplay);
                --i;
                BinTree<int> r;
                read_bintree_int(r, n, i, sumniv, maxplay);
                --i;
                a = BinTree<int>(anterior, l, r);
            }
    }

    void torneo::consultatorneo(){

        cout << nombre << " " << categoria << endl;
    }
